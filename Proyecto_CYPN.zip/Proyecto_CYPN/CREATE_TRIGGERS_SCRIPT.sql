--LLENA NO_FOLIO AUTOMATICAMENTE EN ORDEN DE COMPRAS_CAJAS
CREATE TRIGGER fill_FKEY_orden_de_compra_cajas
ON orden_de_compra AFTER INSERT AS
BEGIN
	UPDATE orden_de_compra_cajas
	SET no_folio = (SELECT DISTINCT MAX(no_folio) FROM orden_de_compra)
	WHERE no_folio = 0;
END;

--LLENA LOS FKEYS DE PRE_PEDIDO
CREATE TRIGGER fill_FKEYS_NOFOLIO_pre_pedido
ON orden_de_compra_cajas AFTER UPDATE AS
BEGIN
	INSERT INTO pre_pedido (no_folio, simbolo)
	SELECT no_folio, simbolo
	FROM orden_de_compra_cajas
	WHERE orden_de_compra_cajas.no_folio = (SELECT DISTINCT max(no_folio) FROM orden_de_compra_cajas);
END;

--LLENA LOS DATOS RESTANTES AUTOMATICAMENTE DE PRE PEDIDO
CREATE TRIGGER fill_DATA_pre_pedido
ON pre_pedido AFTER INSERT AS
BEGIN
	UPDATE pre_pedido
	SET total_importe = (SELECT cajas.precio * orden_de_compra_cajas.cantidad
						FROM cajas, orden_de_compra_cajas
						WHERE cajas.simbolo = (SELECT simbolo FROM INSERTED) AND orden_de_compra_cajas.no_folio = (SELECT MAX(no_folio) FROM orden_de_compra_cajas))
	WHERE no_folio = (SELECT no_folio FROM INSERTED);

	UPDATE pre_pedido
	SET total_metros = (SELECT cajas.aream2 * orden_de_compra_cajas.cantidad
						FROM cajas, orden_de_compra_cajas
						WHERE cajas.simbolo = (SELECT simbolo FROM INSERTED) AND orden_de_compra_cajas.no_folio = (SELECT MAX(no_folio) FROM orden_de_compra_cajas))
	WHERE no_folio = (SELECT no_folio FROM INSERTED);
	UPDATE pre_pedido
	SET total_kg = (SELECT cajas.peso * orden_de_compra_cajas.cantidad
						FROM cajas, orden_de_compra_cajas
						WHERE cajas.simbolo = (SELECT simbolo FROM INSERTED) AND orden_de_compra_cajas.no_folio = (SELECT MAX(no_folio) FROM orden_de_compra_cajas))
	WHERE no_folio = (SELECT no_folio FROM INSERTED);
	RETURN total_kg,total_metros,total_importe;
END;

--LLENA LA TABLA PEDIDO 
CREATE TRIGGER fill_DATA_pedido 
ON pre_pedido AFTER INSERT AS
BEGIN
	INSERT INTO pedido (id)
	SELECT id
	FROM pre_pedido
	WHERE pre_pedido.id = (SELECT MAX(id) FROM pre_pedido);
END;
--LLENA LA TABLA ESTADO PEDIDO
CREATE TRIGGER fill_DATA_estado_pedido
ON pedido AFTER INSERT AS
BEGIN
	INSERT INTO estado_pedido (clave_pedido)
	SELECT clave_pedido
	FROM pedido
	WHERE pedido.clave_pedido = (SELECT MAX(clave_pedido) FROM pedido);

	UPDATE estado_pedido
	SET simbolo = (SELECT simbolo FROM pre_pedido WHERE pre_pedido.id = (SELECT DISTINCT MAX(id) FROM pre_pedido))
	WHERE clave_pedido = (SELECT clave_pedido FROM pedido WHERE clave_pedido = (SELECT DISTINCT MAX(clave_pedido) FROM pedido));
END;