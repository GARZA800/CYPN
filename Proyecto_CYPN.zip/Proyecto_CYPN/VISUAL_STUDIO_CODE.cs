////////////////////////////////////////////////////////////////////////
//Codigo para insertar los datos en orden de compra y llenar el excel.//
////////////////////////////////////////////////////////////////////////
SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");
string sql = ("INSERT INTO orden_de_compra (no_folio, direccion_entrega,fecha_entrega, rfc_cliente, precio_venta) values (@nfolio, @direccion, '" + monthCalendar1.SelectionEnd.ToShortDateString() + "', @rfc, @precio)");
conn.Open();
Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

if (xlApp == null)
{
    MessageBox.Show("Excel is not properly installed");
    return;
}

Excel.Workbook xlWorkBook;
Excel.Worksheet xlWorkSheet;
object misValue = System.Reflection.Missing.Value;


xlWorkBook = xlApp.Workbooks.Open("PRE-PEDIDO MACRO.xls");
xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
xlWorkSheet.Cells[20, 9] = textBox3.Text;
xlWorkSheet.Cells[27, 10] = monthCalendar1.SelectionEnd.ToShortDateString();
xlWorkSheet.Cells[42, 8] = DateTime.Today;

try
{

    SqlCommand cmd = new SqlCommand(sql, conn);
    cmd.Parameters.AddWithValue("@nfolio", textBox1.Text);
    cmd.Parameters.AddWithValue("@rfc", textBox2.Text);
    cmd.Parameters.AddWithValue("@direccion", textBox3.Text);
    cmd.Parameters.AddWithValue("@precio", textBox4.Text);
    cmd.CommandType = CommandType.Text;
    cmd.ExecuteNonQuery();

    MessageBox.Show("¡Los datos han sido guardados con exito!");

    this.Hide();
    var PRE_PEDIDO = new PRE_PEDIDO();
    PRE_PEDIDO.Closed += (s, args) => this.Close();
    PRE_PEDIDO.Show();

    string query = ("SELECT * FROM cajas, pre_pedido, orden_de_compra_cajas  WHERE orden_de_compra_cajas.simbolo = cajas.simbolo AND orden_de_compra_cajas.no_folio = " + textBox1.Text + " AND pre_pedido.no_folio = " + textBox1.Text + "");
    cmd.CommandText = query;
    cmd.CommandType = CommandType.Text;
    SqlDataReader rd = cmd.ExecuteReader();
    while (rd.Read())
    {
        textBox5.Text = rd["folio_pre_pedido"].ToString();
        xlWorkSheet.Cells[5, 10] = rd["folio_pre_pedido"].ToString();
        xlWorkSheet.Cells[27, 2] = rd["cantidad"].ToString();
        xlWorkSheet.Cells[27, 3] = rd["simbolo"].ToString();
        xlWorkSheet.Cells[27, 4] = rd["resistencia"].ToString();
        xlWorkSheet.Cells[27, 5] = rd["tipo"].ToString();
        xlWorkSheet.Cells[27, 6] = rd["colores_impresion"].ToString();
        xlWorkSheet.Cells[27, 7] = rd["cierre"].ToString();
        xlWorkSheet.Cells[27, 9] = rd["aream2"].ToString();
        xlWorkSheet.Cells[31, 4] = rd["largo"].ToString();
        xlWorkSheet.Cells[31, 5] = rd["ancho"].ToString();
        xlWorkSheet.Cells[31, 6] = rd["fondo"].ToString();
        xlWorkSheet.Cells[31, 10] = rd["precio"].ToString();
        xlWorkSheet.Cells[8, 10] = rd["total_metros"].ToString();
        xlWorkSheet.Cells[9, 10] = rd["total_kg"].ToString();
        xlWorkSheet.Cells[10, 10] = rd["total_importe"].ToString();
    }
}
catch (System.Data.SqlClient.SqlException ex)
{
    string msg = "Insert Error: ";
    msg += ex.Message;
    throw new Exception(msg);
}


xlWorkBook.SaveAs("PRE-PEDIDO " + textBox5.Text + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
xlWorkBook.Close();
xlApp.Quit();

releaseObject(xlWorkSheet);
releaseObject(xlWorkBook);
releaseObject(xlApp);

MessageBox.Show("Formulario de Excel creado en la carpeta Documentos.");
conn.Close();
//////////////////////////////////
//Codigo para llenar un combobox//
//////////////////////////////////
SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");
try
{
    conn.Open();
    SqlCommand command = new SqlCommand();
    command.Connection = conn;
    string query = "select * from cajas where simbolo = '" + comboBox1.Text + "'";
    command.CommandText = query;

    SqlDataReader rd = command.ExecuteReader();
    while (rd.Read())
    {
        textBox3.Text = rd["resistencia"].ToString();
        textBox4.Text = rd["tipo"].ToString();
        textBox6.Text = rd["colores_impresion"].ToString();
        textBox7.Text = rd["cierre"].ToString();
        textBox8.Text = rd["aream2"].ToString();
        textBox9.Text = rd["largo"].ToString();
        textBox10.Text = rd["ancho"].ToString();
        textBox11.Text = rd["fondo"].ToString();
        textBox12.Text = rd["precio"].ToString();
        textBox13.Text = rd["peso"].ToString();

    }
    conn.Close();
}
///////////////////////////////////////////
//Codigo para cambiar status en el pedido//
///////////////////////////////////////////
SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");
string sql = ("UPDATE estado_pedido SET estado = @liberado WHERE clave_pedido = " + comboBox2.Text);
try
{
    conn.Open();
    SqlCommand cmd = new SqlCommand(sql, conn);
    cmd.Parameters.AddWithValue("@liberado", "LIBERADO");
    cmd.CommandType = CommandType.Text;
    cmd.ExecuteNonQuery();

    this.Hide();
    var ESTADO_PEDIDO = new Estado_pedido();
    ESTADO_PEDIDO.Closed += (s, args) => this.Close();
    ESTADO_PEDIDO.Show();

}