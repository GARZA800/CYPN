CREATE TABLE cliente (
                rfc_cliente VARCHAR(30) NOT NULL,
                nombre VARCHAR(30) NOT NULL,
                direccion VARCHAR(128) NOT NULL,
                telefono INTEGER,
                CONSTRAINT cliente_pkey PRIMARY KEY (rfc_cliente)
);

CREATE TABLE cajas (
                simbolo VARCHAR(30) NOT NULL,
                resistencia VARCHAR(30) NOT NULL,
                tipo VARCHAR(30) NOT NULL,
                colores_impresion VARCHAR(30),
                cierre VARCHAR(30),
                aream2 FLOAT NOT NULL,
                largo FLOAT NOT NULL,
                ancho FLOAT NOT NULL,
                fondo FLOAT NOT NULL,
                peso FLOAT,
                precio FLOAT NOT NULL,
                CONSTRAINT cajas_pkey PRIMARY KEY (simbolo)
);

CREATE TABLE orden_de_compra (
                no_folio INTEGER NOT NULL,
                direccion_entrega VARCHAR(128) NOT NULL,
                fecha_entrega DATE NOT NULL,
                rfc_cliente VARCHAR(30) NOT NULL,
                precio_venta INTEGER NOT NULL,
                CONSTRAINT orden_de_compra_pkey PRIMARY KEY (no_folio)
);

CREATE TABLE orden_de_compra_cajas (
                simbolo VARCHAR(30) NOT NULL,
                no_folio INTEGER DEFAULT 0,
                cantidad INTEGER NOT NULL,
                CONSTRAINT orden_de_compra_cajas_pk PRIMARY KEY (simbolo, no_folio)
);

CREATE TABLE pre_pedido (
                id INT IDENTITY(1,1),
                folio_pre_pedido AS 'CPN-' + CAST(id AS VARCHAR(10)),
                no_folio INTEGER DEFAULT 0,
                no_cajasxatado INTEGER NOT NULL DEFAULT 25,
                --lugar_entrega VARCHAR(128),
                --fecha_entrega DATE,
                --precio FLOAT NOT NULL,
                --importe FLOAT,
                simbolo VARCHAR(30) NOT NULL DEFAULT '0',
                agente VARCHAR(30) DEFAULT 'DI',
                total_importe FLOAT,
                total_metros FLOAT,
                total_kg FLOAT,
                CONSTRAINT pre_pedido_pkey PRIMARY KEY (id)
);

CREATE TABLE pedido (
                clave_pedido INTEGER IDENTITY(1,1),
                --no_folio INTEGER NOT NULL,
                id INT NOT NULL,
                CONSTRAINT pedido_pkey PRIMARY KEY (clave_pedido)
);

CREATE TABLE estado_pedido (
                clave_pedido INTEGER,
                simbolo VARCHAR(30),
                estado VARCHAR(15) NOT NULL DEFAULT 'EN PROCESO'
);

ALTER TABLE orden_de_compra_cajas ADD CONSTRAINT orden_de_compra_simbolo_fkey
FOREIGN KEY (simbolo)
REFERENCES cajas (simbolo)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE orden_de_compra_cajas ADD CONSTRAINT orden_de_compra_no_folio_fkey
FOREIGN KEY (no_folio)
REFERENCES orden_de_compra (no_folio)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE orden_de_compra ADD CONSTRAINT orden_de_compra_rfc_cliente_fkey
FOREIGN KEY (rfc_cliente)
REFERENCES cliente (rfc_cliente)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE pre_pedido ADD CONSTRAINT pre_pedido_simbolo_fkey
FOREIGN KEY (simbolo)
REFERENCES cajas (simbolo)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE pre_pedido ADD CONSTRAINT pre_pedido_no_folio_fkey
FOREIGN KEY (no_folio)
REFERENCES orden_de_compra (no_folio)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE pedido ADD CONSTRAINT pedido_pre_pedido_fkey
FOREIGN KEY (id)
REFERENCES pre_pedido (id)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE estado_pedido ADD CONSTRAINT estado_pedido_clave_pedido_fkey
FOREIGN KEY (clave_pedido)
REFERENCES pedido (clave_pedido)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;

ALTER TABLE estado_pedido ADD CONSTRAINT estado_pedido_simbolo_fkey
FOREIGN KEY (simbolo)
REFERENCES cajas (simbolo)
ON DELETE NO ACTION
ON UPDATE CASCADE
/*NOT DEFERRABLE*/;