﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;


namespace CYPN
{
    public partial class Estado_pedido : MaterialForm
    {
        public Estado_pedido()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void Estado_pedido_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'cYPNDataSet.CHECK_STATUS_RETENIDO' Puede moverla o quitarla según sea necesario.
            this.cHECK_STATUS_RETENIDOTableAdapter.Fill(this.cYPNDataSet.CHECK_STATUS_RETENIDO);
            // TODO: esta línea de código carga datos en la tabla 'cYPNDataSet.CHECK_STATUS_LIBERADO' Puede moverla o quitarla según sea necesario.
            this.cHECK_STATUS_LIBERADOTableAdapter.Fill(this.cYPNDataSet.CHECK_STATUS_LIBERADO);
            // TODO: esta línea de código carga datos en la tabla 'cYPNDataSet.CHECK_STATUS_ENPROCESO' Puede moverla o quitarla según sea necesario.
            this.cHECK_STATUS_ENPROCESOTableAdapter.Fill(this.cYPNDataSet.CHECK_STATUS_ENPROCESO);

            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "select * from CHECK_STATUS_LIBERADO";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    comboBox1.Items.Add(rd["clave_pedido"].ToString());
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "select * from CHECK_STATUS_ENPROCESO";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    comboBox2.Items.Add(rd["clave_pedido"].ToString());
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "select * from CHECK_STATUS_RETENIDO";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    comboBox3.Items.Add(rd["clave_pedido"].ToString());
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cHECK_STATUS_ENPROCESOBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }



        private void cHECK_STATUS_ENPROCESODataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }


        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            string sql = ("UPDATE estado_pedido SET estado = @liberado WHERE clave_pedido = " + comboBox2.Text);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@liberado", "LIBERADO");
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                this.Hide();
                var ESTADO_PEDIDO = new Estado_pedido();
                ESTADO_PEDIDO.Closed += (s, args) => this.Close();
                ESTADO_PEDIDO.Show();

            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error: ";
                msg += ex.Message;
                throw new Exception(msg);
            }
            finally
            {
                conn.Close();
            }
            cHECK_STATUS_ENPROCESODataGridView.Refresh();
            //Refresh.tabPage2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            string sql = ("UPDATE estado_pedido SET estado = @retenido WHERE clave_pedido = " + comboBox2.Text);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@retenido", "RETENIDO");
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                this.Hide();
                var ESTADO_PEDIDO = new Estado_pedido();
                ESTADO_PEDIDO.Closed += (s, args) => this.Close();
                ESTADO_PEDIDO.Show();
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error: ";
                msg += ex.Message;
                throw new Exception(msg);
            }
            finally
            {
                conn.Close();
            }
            cHECK_STATUS_ENPROCESODataGridView.Refresh();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            string sql = ("UPDATE estado_pedido SET estado = @liberado WHERE clave_pedido = " + comboBox3.Text + "");
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@liberado", "LIBERADO");
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                this.Hide();
                var ESTADO_PEDIDO = new Estado_pedido();
                ESTADO_PEDIDO.Closed += (s, args) => this.Close();
                ESTADO_PEDIDO.Show();
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error: ";
                msg += ex.Message;
                throw new Exception(msg);
            }
            finally
            {
                conn.Close();
            }

            cHECK_STATUS_ENPROCESODataGridView.Refresh();
        }

        private void cHECK_STATUS_ENPROCESODataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void cHECK_STATUS_LIBERADODataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var MENU_USUARIO = new MENU_USUARIO();
            MENU_USUARIO.Closed += (s, args) => this.Close();
            MENU_USUARIO.Show();
        }
    }
}