﻿namespace CYPN
{
    partial class Estado_pedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.cHECK_STATUS_LIBERADODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cHECK_STATUS_LIBERADOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cYPNDataSet = new CYPN.CYPNDataSet();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cHECK_STATUS_ENPROCESODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cHECK_STATUS_ENPROCESOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cHECK_STATUS_RETENIDODataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cHECK_STATUS_RETENIDOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.button9 = new System.Windows.Forms.Button();
            this.cHECK_STATUS_ENPROCESOTableAdapter = new CYPN.CYPNDataSetTableAdapters.CHECK_STATUS_ENPROCESOTableAdapter();
            this.tableAdapterManager = new CYPN.CYPNDataSetTableAdapters.TableAdapterManager();
            this.cajasTableAdapter1 = new CYPN.CYPNDataSetTableAdapters.cajasTableAdapter();
            this.cHECK_STATUS_LIBERADOTableAdapter = new CYPN.CYPNDataSetTableAdapters.CHECK_STATUS_LIBERADOTableAdapter();
            this.cHECK_STATUS_RETENIDOTableAdapter = new CYPN.CYPNDataSetTableAdapters.CHECK_STATUS_RETENIDOTableAdapter();
            this.materialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_LIBERADODataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_LIBERADOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cYPNDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_ENPROCESODataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_ENPROCESOBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_RETENIDODataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_RETENIDOBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 72);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(593, 304);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.cHECK_STATUS_LIBERADODataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(585, 278);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Liberadas";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(403, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(131, 21);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(414, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "Generar Factura";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // cHECK_STATUS_LIBERADODataGridView
            // 
            this.cHECK_STATUS_LIBERADODataGridView.AutoGenerateColumns = false;
            this.cHECK_STATUS_LIBERADODataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cHECK_STATUS_LIBERADODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cHECK_STATUS_LIBERADODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.cHECK_STATUS_LIBERADODataGridView.DataSource = this.cHECK_STATUS_LIBERADOBindingSource;
            this.cHECK_STATUS_LIBERADODataGridView.Location = new System.Drawing.Point(3, 2);
            this.cHECK_STATUS_LIBERADODataGridView.Name = "cHECK_STATUS_LIBERADODataGridView";
            this.cHECK_STATUS_LIBERADODataGridView.Size = new System.Drawing.Size(344, 276);
            this.cHECK_STATUS_LIBERADODataGridView.TabIndex = 0;
            this.cHECK_STATUS_LIBERADODataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cHECK_STATUS_LIBERADODataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "clave_pedido";
            this.dataGridViewTextBoxColumn1.HeaderText = "clave_pedido";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "simbolo";
            this.dataGridViewTextBoxColumn2.HeaderText = "simbolo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "estado";
            this.dataGridViewTextBoxColumn3.HeaderText = "estado";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // cHECK_STATUS_LIBERADOBindingSource
            // 
            this.cHECK_STATUS_LIBERADOBindingSource.DataMember = "CHECK_STATUS_LIBERADO";
            this.cHECK_STATUS_LIBERADOBindingSource.DataSource = this.cYPNDataSet;
            // 
            // cYPNDataSet
            // 
            this.cYPNDataSet.DataSetName = "CYPNDataSet";
            this.cYPNDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.cHECK_STATUS_ENPROCESODataGridView);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(585, 278);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "En proceso";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // cHECK_STATUS_ENPROCESODataGridView
            // 
            this.cHECK_STATUS_ENPROCESODataGridView.AutoGenerateColumns = false;
            this.cHECK_STATUS_ENPROCESODataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cHECK_STATUS_ENPROCESODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cHECK_STATUS_ENPROCESODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.cHECK_STATUS_ENPROCESODataGridView.DataSource = this.cHECK_STATUS_ENPROCESOBindingSource;
            this.cHECK_STATUS_ENPROCESODataGridView.Location = new System.Drawing.Point(0, 0);
            this.cHECK_STATUS_ENPROCESODataGridView.Name = "cHECK_STATUS_ENPROCESODataGridView";
            this.cHECK_STATUS_ENPROCESODataGridView.Size = new System.Drawing.Size(346, 278);
            this.cHECK_STATUS_ENPROCESODataGridView.TabIndex = 8;
            this.cHECK_STATUS_ENPROCESODataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cHECK_STATUS_ENPROCESODataGridView_CellContentClick_1);
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "clave_pedido";
            this.dataGridViewTextBoxColumn4.HeaderText = "clave_pedido";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "simbolo";
            this.dataGridViewTextBoxColumn5.HeaderText = "simbolo";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "estado";
            this.dataGridViewTextBoxColumn6.HeaderText = "estado";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // cHECK_STATUS_ENPROCESOBindingSource
            // 
            this.cHECK_STATUS_ENPROCESOBindingSource.DataMember = "CHECK_STATUS_ENPROCESO";
            this.cHECK_STATUS_ENPROCESOBindingSource.DataSource = this.cYPNDataSet;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(497, 71);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(79, 33);
            this.button5.TabIndex = 7;
            this.button5.Text = "Retener";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(409, 25);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(131, 21);
            this.comboBox2.TabIndex = 6;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(374, 71);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(78, 33);
            this.button6.TabIndex = 5;
            this.button6.Text = "Liberar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.cHECK_STATUS_RETENIDODataGridView);
            this.tabPage3.Controls.Add(this.comboBox3);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(585, 278);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Retenidas";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cHECK_STATUS_RETENIDODataGridView
            // 
            this.cHECK_STATUS_RETENIDODataGridView.AutoGenerateColumns = false;
            this.cHECK_STATUS_RETENIDODataGridView.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cHECK_STATUS_RETENIDODataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cHECK_STATUS_RETENIDODataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.cHECK_STATUS_RETENIDODataGridView.DataSource = this.cHECK_STATUS_RETENIDOBindingSource;
            this.cHECK_STATUS_RETENIDODataGridView.Location = new System.Drawing.Point(0, 0);
            this.cHECK_STATUS_RETENIDODataGridView.Name = "cHECK_STATUS_RETENIDODataGridView";
            this.cHECK_STATUS_RETENIDODataGridView.Size = new System.Drawing.Size(343, 278);
            this.cHECK_STATUS_RETENIDODataGridView.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "clave_pedido";
            this.dataGridViewTextBoxColumn7.HeaderText = "clave_pedido";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "simbolo";
            this.dataGridViewTextBoxColumn8.HeaderText = "simbolo";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "estado";
            this.dataGridViewTextBoxColumn9.HeaderText = "estado";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // cHECK_STATUS_RETENIDOBindingSource
            // 
            this.cHECK_STATUS_RETENIDOBindingSource.DataMember = "CHECK_STATUS_RETENIDO";
            this.cHECK_STATUS_RETENIDOBindingSource.DataSource = this.cYPNDataSet;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(397, 27);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(131, 21);
            this.comboBox3.TabIndex = 10;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(418, 68);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(89, 33);
            this.button9.TabIndex = 9;
            this.button9.Text = "Liberar";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // cHECK_STATUS_ENPROCESOTableAdapter
            // 
            this.cHECK_STATUS_ENPROCESOTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.cajasTableAdapter = this.cajasTableAdapter1;
            this.tableAdapterManager.clienteTableAdapter = null;
            this.tableAdapterManager.estado_pedidoTableAdapter = null;
            this.tableAdapterManager.orden_de_compra_cajasTableAdapter = null;
            this.tableAdapterManager.orden_de_compraTableAdapter = null;
            this.tableAdapterManager.pedidoTableAdapter = null;
            this.tableAdapterManager.pre_pedidoTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = CYPN.CYPNDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // cajasTableAdapter1
            // 
            this.cajasTableAdapter1.ClearBeforeFill = true;
            // 
            // cHECK_STATUS_LIBERADOTableAdapter
            // 
            this.cHECK_STATUS_LIBERADOTableAdapter.ClearBeforeFill = true;
            // 
            // cHECK_STATUS_RETENIDOTableAdapter
            // 
            this.cHECK_STATUS_RETENIDOTableAdapter.ClearBeforeFill = true;
            // 
            // materialFlatButton1
            // 
            this.materialFlatButton1.AutoSize = true;
            this.materialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton1.BackColor = System.Drawing.Color.White;
            this.materialFlatButton1.Depth = 0;
            this.materialFlatButton1.Location = new System.Drawing.Point(16, 390);
            this.materialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialFlatButton1.Name = "materialFlatButton1";
            this.materialFlatButton1.Primary = false;
            this.materialFlatButton1.Size = new System.Drawing.Size(80, 36);
            this.materialFlatButton1.TabIndex = 5;
            this.materialFlatButton1.Text = "Regresar";
            this.materialFlatButton1.UseVisualStyleBackColor = false;
            this.materialFlatButton1.Click += new System.EventHandler(this.materialFlatButton1_Click);
            // 
            // Estado_pedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(625, 441);
            this.Controls.Add(this.materialFlatButton1);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "Estado_pedido";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estado del pedido";
            this.Load += new System.EventHandler(this.Estado_pedido_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_LIBERADODataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_LIBERADOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cYPNDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_ENPROCESODataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_ENPROCESOBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_RETENIDODataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cHECK_STATUS_RETENIDOBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private CYPNDataSet cYPNDataSet;
        private System.Windows.Forms.BindingSource cHECK_STATUS_ENPROCESOBindingSource;
        private CYPNDataSetTableAdapters.CHECK_STATUS_ENPROCESOTableAdapter cHECK_STATUS_ENPROCESOTableAdapter;
        private CYPNDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private CYPNDataSetTableAdapters.cajasTableAdapter cajasTableAdapter1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.BindingSource cHECK_STATUS_LIBERADOBindingSource;
        private CYPNDataSetTableAdapters.CHECK_STATUS_LIBERADOTableAdapter cHECK_STATUS_LIBERADOTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView cHECK_STATUS_LIBERADODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridView cHECK_STATUS_ENPROCESODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.BindingSource cHECK_STATUS_RETENIDOBindingSource;
        private CYPNDataSetTableAdapters.CHECK_STATUS_RETENIDOTableAdapter cHECK_STATUS_RETENIDOTableAdapter;
        private System.Windows.Forms.DataGridView cHECK_STATUS_RETENIDODataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton1;
    }
}