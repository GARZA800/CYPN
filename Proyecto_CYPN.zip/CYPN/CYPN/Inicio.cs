﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace CYPN
{
    public partial class Inicio : MaterialForm
    {
        public Inicio()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            /*SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "SELECT password_usuario FROM usuarios WHERE login_name = " + textBox1.Text;
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                string password = rd["password_usuario"].ToString();*/

                if (textBox1.Text == "Usuario" && textBox2.Text == "12345")
                {
                    this.Hide();
                    var MENU_USUARIO = new MENU_USUARIO();
                    MENU_USUARIO.Closed += (s, args) => this.Close();
                    MENU_USUARIO.Show();
                }
                else if (textBox1.Text == "Admin" && textBox2.Text == "12345")
                {
                    this.Hide();
                    var MENU_ADMIN = new MENU_ADMIN();
                    MENU_ADMIN.Closed += (s, args) => this.Close();
                    MENU_ADMIN.Show();
                }
                else
                {
                    MessageBox.Show("Usuario y/o contraseña son incorrectos.");
                }

           /* }
            catch (System.Data.SqlClient.SqlException ex)
            {
                string msg = "Insert Error: ";
                msg += ex.Message;
                throw new Exception(msg);
            }

            finally
            {
                conn.Close();
            }*/

        
        }
    }
}
