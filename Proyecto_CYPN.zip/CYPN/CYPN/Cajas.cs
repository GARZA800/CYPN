﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;

namespace CYPN
{
    public partial class Cajas : MaterialForm
    {
        public Cajas()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);

        }

        private void Cajas_Load(object sender, EventArgs e)
        {
            //this.cajasTableAdapter.Fill(this.cYPNDataSet.cajas);
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "select * from cajas";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    comboBox1.Items.Add(rd["simbolo"].ToString());
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void cajasBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cajasBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.cYPNDataSet);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "select * from cajas where simbolo = '" + comboBox1.Text + "'";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    textBox3.Text = rd["resistencia"].ToString();
                    textBox4.Text = rd["tipo"].ToString();
                    textBox6.Text = rd["colores_impresion"].ToString();
                    textBox7.Text = rd["cierre"].ToString();
                    textBox8.Text = rd["aream2"].ToString();
                    textBox9.Text = rd["largo"].ToString();
                    textBox10.Text = rd["ancho"].ToString();
                    textBox11.Text = rd["fondo"].ToString();
                    textBox12.Text = rd["precio"].ToString();
                    textBox13.Text = rd["peso"].ToString();

                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var PRE_PEDIDO = new PRE_PEDIDO();
            PRE_PEDIDO.Closed += (s, args) => this.Close();
        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else
            {
                SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

                string sql = ("INSERT INTO orden_de_compra_cajas (simbolo, cantidad) values (@sim, @cant)");
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@sim", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@cant", textBox2.Text);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Se han guardado los datos con éxito.");

                    this.Hide();

                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    string msg = "Insert Error: ";
                    msg += ex.Message;
                    throw new Exception(msg);
                }

                finally
                {
                    conn.Close();
                }
            }
        }
    }
}
