﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;

namespace CYPN
{
    public partial class MENU_ADMIN : MaterialForm
    {
        public MENU_ADMIN()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void MENU_ADMIN_Load(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var NUEVA_CAJA = new NUEVA_CAJA();
            NUEVA_CAJA.Closed += (s, args) => this.Close();
            NUEVA_CAJA.Show();
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var NUEVO_CLIENTE= new NUEVO_CLIENTE();
            NUEVO_CLIENTE.Closed += (s, args) => this.Close();
            NUEVO_CLIENTE.Show();
        }

        private void materialFlatButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            var INICIO = new Inicio();
            INICIO.Closed += (s, args) => this.Close();
            INICIO.Show();
        }
    }
}
