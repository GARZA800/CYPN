﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;

namespace CYPN
{
    public partial class NUEVO_CLIENTE : MaterialForm
    {
        public NUEVO_CLIENTE()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void NUEVO_CLIENTE_Load(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            if (textbox1.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else {
                SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");
                string sql = ("INSERT INTO cliente (rfc_cliente, direccion,telefono,nombre) values (@rfc, @direccion, @telefono, @nombre)");
                conn.Open();
                try
                {

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@rfc", textBox3.Text);
                    cmd.Parameters.AddWithValue("@direccion", textBox2.Text);
                    cmd.Parameters.AddWithValue("@telefono", textBox4.Text);
                    cmd.Parameters.AddWithValue("@nombre", textbox1.Text);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("¡El cliente ha sido guardado!");

                    this.Hide();
                    var MENU_ADMIN = new MENU_ADMIN();
                    MENU_ADMIN.Closed += (s, args) => this.Close();
                    MENU_ADMIN.Show();
                }

                catch (System.Data.SqlClient.SqlException ex)
                {
                    string msg = "Insert Error: ";
                    msg += ex.Message;
                    throw new Exception(msg);
                }
            }
        }

        private void materialFlatButton3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que desea cancelar? Se perderan los cambios realizados", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                var MENU_ADMIN = new MENU_ADMIN();
                MENU_ADMIN.Closed += (s, args) => this.Close();
                MENU_ADMIN.Show();
            }
        }
    }
}
