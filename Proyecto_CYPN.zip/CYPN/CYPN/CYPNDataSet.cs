﻿namespace CYPN
{


    partial class CYPNDataSet
    {
        partial class clienteDataTable
        {
        }
    }
}

namespace CYPN.CYPNDataSetTableAdapters {
    
    
    public partial class clienteTableAdapter {
    }
}
