﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.CSharp;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;


namespace CYPN
{
    public partial class PRE_PEDIDO : MaterialForm
    {
        public PRE_PEDIDO()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);

        }

        private void PRE_PEDIDO_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "select * from cliente";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    comboBox1.Items.Add(rd["nombre"].ToString());
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = conn;
                string query = "SELECT * FROM cliente  WHERE cliente.nombre = '"+ comboBox1.Text +"'";
                command.CommandText = query;

                SqlDataReader rd = command.ExecuteReader();

                while (rd.Read())
                {
                    textBox2.Text = rd["rfc_cliente"].ToString();
                    textBox3.Text = rd["direccion"].ToString();
                }
                conn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            var Cajas = new Cajas();
            Cajas.Show();
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }

            else if (textBox2.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }

            else if (textBox4.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }

            else if (comboBox1.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }

            else if (monthCalendar1.SelectionEnd.ToShortDateString() == "")
            {
                MessageBox.Show("ATENCIÓN: Faltan datos por ingresar.");
            }
            else {
                SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");

                string sql = ("INSERT INTO orden_de_compra (no_folio, direccion_entrega,fecha_entrega, rfc_cliente, precio_venta) values (@nfolio, @direccion, '" + monthCalendar1.SelectionEnd.ToShortDateString() + "', @rfc, @precio)");
                //string query = ("SELECT * FROM cajas, pre_pedido, orden_de_compra_cajas  WHERE orden_de_compra_cajas.simbolo = cajas.simbolo AND orden_de_compra_cajas.no_folio = " + textBox1.Text + " pre_pedido.no_folio = "+textBox1.Text+"");
                conn.Open();
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed");
                    return;
                }

                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;


                xlWorkBook = xlApp.Workbooks.Open("PRE-PEDIDO MACRO.xls");
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[20, 9] = textBox3.Text;
                xlWorkSheet.Cells[27, 10] = monthCalendar1.SelectionEnd.ToShortDateString();
                xlWorkSheet.Cells[42, 8] = DateTime.Today;

                try
                {

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@nfolio", textBox1.Text);
                    cmd.Parameters.AddWithValue("@rfc", textBox2.Text);
                    cmd.Parameters.AddWithValue("@direccion", textBox3.Text);
                    cmd.Parameters.AddWithValue("@precio", textBox4.Text);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("¡Los datos han sido guardados con exito!");

                    this.Hide();
                    var PRE_PEDIDO = new PRE_PEDIDO();
                    PRE_PEDIDO.Closed += (s, args) => this.Close();
                    PRE_PEDIDO.Show();

                    string query = ("SELECT * FROM cajas, pre_pedido, orden_de_compra_cajas  WHERE orden_de_compra_cajas.simbolo = cajas.simbolo AND orden_de_compra_cajas.no_folio = " + textBox1.Text + " AND pre_pedido.no_folio = " + textBox1.Text + "");
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader rd = cmd.ExecuteReader();
                    while (rd.Read())
                    {
                        textBox5.Text = rd["folio_pre_pedido"].ToString();
                        xlWorkSheet.Cells[5, 10] = rd["folio_pre_pedido"].ToString();
                        xlWorkSheet.Cells[27, 2] = rd["cantidad"].ToString();
                        xlWorkSheet.Cells[27, 3] = rd["simbolo"].ToString();
                        xlWorkSheet.Cells[27, 4] = rd["resistencia"].ToString();
                        xlWorkSheet.Cells[27, 5] = rd["tipo"].ToString();
                        xlWorkSheet.Cells[27, 6] = rd["colores_impresion"].ToString();
                        xlWorkSheet.Cells[27, 7] = rd["cierre"].ToString();
                        xlWorkSheet.Cells[27, 9] = rd["aream2"].ToString();
                        xlWorkSheet.Cells[31, 4] = rd["largo"].ToString();
                        xlWorkSheet.Cells[31, 5] = rd["ancho"].ToString();
                        xlWorkSheet.Cells[31, 6] = rd["fondo"].ToString();
                        xlWorkSheet.Cells[31, 10] = rd["precio"].ToString();
                        xlWorkSheet.Cells[8, 10] = rd["total_metros"].ToString();
                        xlWorkSheet.Cells[9, 10] = rd["total_kg"].ToString();
                        xlWorkSheet.Cells[10, 10] = rd["total_importe"].ToString();
                    }
                }
                catch (System.Data.SqlClient.SqlException ex)
                {
                    string msg = "Insert Error: ";
                    msg += ex.Message;
                    throw new Exception(msg);
                }


                xlWorkBook.SaveAs("PRE-PEDIDO " + textBox5.Text + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close();
                xlApp.Quit();

                releaseObject(xlWorkSheet);
                releaseObject(xlWorkBook);
                releaseObject(xlApp);

                MessageBox.Show("Formulario de Excel creado en la carpeta Documentos.");
                conn.Close();
            }

        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void materialFlatButton3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que desea cancelar? Se perderan los cambios realizados", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                var MENU_USUARIO = new MENU_USUARIO();
                MENU_USUARIO.Closed += (s, args) => this.Close();
                MENU_USUARIO.Show();
            }
        }
    }
}
