﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;

namespace CYPN
{
    public partial class NUEVA_CAJA : MaterialForm
    {
        public NUEVA_CAJA()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void NUEVA_CAJA_Load(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            if (materialSingleLineTextField1.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox3.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox4.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox6.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox7.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox8.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox9.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox10.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox11.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else if (textBox13.Text == "")
            {
                MessageBox.Show("ATENCIÓN: Falta datos por ingresar.");
            }

            else
            {
                SqlConnection conn = new SqlConnection(@"Data Source=MAXSEGOVIA\SQLEXPRESS;Initial Catalog=CYPN;Integrated Security=True");
                string sql = ("INSERT INTO cajas (simbolo, resistencia, tipo, colores_impresion, cierre, aream2, largo, ancho, fondo, peso, precio) values (@simbolo, @resistencia, @tipo, @colores, @cierre, @area, @largo, @ancho, @fondo, @peso, @precio)");
                conn.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@simbolo", materialSingleLineTextField1.Text);
                    cmd.Parameters.AddWithValue("@resistencia", textBox4.Text);
                    cmd.Parameters.AddWithValue("@tipo", textBox3.Text);
                    cmd.Parameters.AddWithValue("@colores", textBox7.Text);
                    cmd.Parameters.AddWithValue("@cierre", textBox6.Text);
                    cmd.Parameters.AddWithValue("@area", textBox10.Text);
                    cmd.Parameters.AddWithValue("@largo", textBox8.Text);
                    cmd.Parameters.AddWithValue("@ancho", textBox9.Text);
                    cmd.Parameters.AddWithValue("@fondo", textBox11.Text);
                    cmd.Parameters.AddWithValue("@peso", textBox12.Text);
                    cmd.Parameters.AddWithValue("@precio", textBox13.Text);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("¡La caja ha sido guardada!");

                    this.Hide();
                    var MENU_ADMIN = new MENU_ADMIN();
                    MENU_ADMIN.Closed += (s, args) => this.Close();
                    MENU_ADMIN.Show();
                }

                catch (System.Data.SqlClient.SqlException ex)
                {
                    string msg = "Insert Error: ";
                    msg += ex.Message;
                    throw new Exception(msg);
                }
            }
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Seguro que desea cancelar? Se perderan los cambios realizados", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                var MENU_ADMIN = new MENU_ADMIN();
                MENU_ADMIN.Closed += (s, args) => this.Close();
                MENU_ADMIN.Show();
            }
        }
    }
}
