﻿namespace CYPN
{
    partial class Cajas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cYPNDataSet = new CYPN.CYPNDataSet();
            this.cajasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cajasTableAdapter = new CYPN.CYPNDataSetTableAdapters.cajasTableAdapter();
            this.tableAdapterManager = new CYPN.CYPNDataSetTableAdapters.TableAdapterManager();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox4 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox2 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox6 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox7 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox8 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox13 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox10 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox11 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox9 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.textBox12 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialFlatButton2 = new MaterialSkin.Controls.MaterialFlatButton();
            ((System.ComponentModel.ISupportInitialize)(this.cYPNDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cajasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(59, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Simbolo de Caja";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(59, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cantidad de Cajas";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Enabled = false;
            this.label6.Location = new System.Drawing.Point(437, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Resistencia";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Enabled = false;
            this.label3.Location = new System.Drawing.Point(283, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Tipo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Enabled = false;
            this.label4.Location = new System.Drawing.Point(437, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Colores de Impresión";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Enabled = false;
            this.label7.Location = new System.Drawing.Point(284, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Cierre";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Enabled = false;
            this.label8.Location = new System.Drawing.Point(283, 266);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Área m2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Enabled = false;
            this.label9.Location = new System.Drawing.Point(283, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Largo";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Enabled = false;
            this.label10.Location = new System.Drawing.Point(438, 208);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "Ancho";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Enabled = false;
            this.label11.Location = new System.Drawing.Point(437, 266);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "Fondo";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Enabled = false;
            this.label12.Location = new System.Drawing.Point(283, 329);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 35;
            this.label12.Text = "Peso";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Enabled = false;
            this.label13.Location = new System.Drawing.Point(437, 329);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 13);
            this.label13.TabIndex = 33;
            this.label13.Text = "Precio por millar";
            // 
            // cYPNDataSet
            // 
            this.cYPNDataSet.DataSetName = "CYPNDataSet";
            this.cYPNDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cajasBindingSource
            // 
            this.cajasBindingSource.DataMember = "cajas";
            this.cajasBindingSource.DataSource = this.cYPNDataSet;
            // 
            // cajasTableAdapter
            // 
            this.cajasTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.cajasTableAdapter = this.cajasTableAdapter;
            this.tableAdapterManager.clienteTableAdapter = null;
            this.tableAdapterManager.estado_pedidoTableAdapter = null;
            this.tableAdapterManager.orden_de_compra_cajasTableAdapter = null;
            this.tableAdapterManager.orden_de_compraTableAdapter = null;
            this.tableAdapterManager.pedidoTableAdapter = null;
            this.tableAdapterManager.pre_pedidoTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = CYPN.CYPNDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.White;
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(62, 183);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(124, 21);
            this.comboBox1.TabIndex = 38;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox3
            // 
            this.textBox3.Depth = 0;
            this.textBox3.Enabled = false;
            this.textBox3.Hint = "";
            this.textBox3.Location = new System.Drawing.Point(440, 105);
            this.textBox3.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox3.Name = "textBox3";
            this.textBox3.PasswordChar = '\0';
            this.textBox3.SelectedText = "";
            this.textBox3.SelectionLength = 0;
            this.textBox3.SelectionStart = 0;
            this.textBox3.Size = new System.Drawing.Size(124, 23);
            this.textBox3.TabIndex = 39;
            this.textBox3.UseSystemPasswordChar = false;
            // 
            // textBox4
            // 
            this.textBox4.Depth = 0;
            this.textBox4.Enabled = false;
            this.textBox4.Hint = "";
            this.textBox4.Location = new System.Drawing.Point(286, 105);
            this.textBox4.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '\0';
            this.textBox4.SelectedText = "";
            this.textBox4.SelectionLength = 0;
            this.textBox4.SelectionStart = 0;
            this.textBox4.Size = new System.Drawing.Size(124, 23);
            this.textBox4.TabIndex = 40;
            this.textBox4.UseSystemPasswordChar = false;
            // 
            // textBox2
            // 
            this.textBox2.Depth = 0;
            this.textBox2.Hint = "";
            this.textBox2.Location = new System.Drawing.Point(62, 245);
            this.textBox2.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '\0';
            this.textBox2.SelectedText = "";
            this.textBox2.SelectionLength = 0;
            this.textBox2.SelectionStart = 0;
            this.textBox2.Size = new System.Drawing.Size(124, 23);
            this.textBox2.TabIndex = 41;
            this.textBox2.UseSystemPasswordChar = false;
            // 
            // textBox6
            // 
            this.textBox6.Depth = 0;
            this.textBox6.Enabled = false;
            this.textBox6.Hint = "";
            this.textBox6.Location = new System.Drawing.Point(440, 164);
            this.textBox6.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox6.Name = "textBox6";
            this.textBox6.PasswordChar = '\0';
            this.textBox6.SelectedText = "";
            this.textBox6.SelectionLength = 0;
            this.textBox6.SelectionStart = 0;
            this.textBox6.Size = new System.Drawing.Size(124, 23);
            this.textBox6.TabIndex = 42;
            this.textBox6.UseSystemPasswordChar = false;
            // 
            // textBox7
            // 
            this.textBox7.Depth = 0;
            this.textBox7.Enabled = false;
            this.textBox7.Hint = "";
            this.textBox7.Location = new System.Drawing.Point(286, 164);
            this.textBox7.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox7.Name = "textBox7";
            this.textBox7.PasswordChar = '\0';
            this.textBox7.SelectedText = "";
            this.textBox7.SelectionLength = 0;
            this.textBox7.SelectionStart = 0;
            this.textBox7.Size = new System.Drawing.Size(124, 23);
            this.textBox7.TabIndex = 43;
            this.textBox7.UseSystemPasswordChar = false;
            // 
            // textBox8
            // 
            this.textBox8.Depth = 0;
            this.textBox8.Enabled = false;
            this.textBox8.Hint = "";
            this.textBox8.Location = new System.Drawing.Point(286, 284);
            this.textBox8.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox8.Name = "textBox8";
            this.textBox8.PasswordChar = '\0';
            this.textBox8.SelectedText = "";
            this.textBox8.SelectionLength = 0;
            this.textBox8.SelectionStart = 0;
            this.textBox8.Size = new System.Drawing.Size(124, 23);
            this.textBox8.TabIndex = 44;
            this.textBox8.UseSystemPasswordChar = false;
            // 
            // textBox13
            // 
            this.textBox13.Depth = 0;
            this.textBox13.Enabled = false;
            this.textBox13.Hint = "";
            this.textBox13.Location = new System.Drawing.Point(286, 345);
            this.textBox13.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox13.Name = "textBox13";
            this.textBox13.PasswordChar = '\0';
            this.textBox13.SelectedText = "";
            this.textBox13.SelectionLength = 0;
            this.textBox13.SelectionStart = 0;
            this.textBox13.Size = new System.Drawing.Size(124, 23);
            this.textBox13.TabIndex = 45;
            this.textBox13.UseSystemPasswordChar = false;
            // 
            // textBox10
            // 
            this.textBox10.Depth = 0;
            this.textBox10.Enabled = false;
            this.textBox10.Hint = "";
            this.textBox10.Location = new System.Drawing.Point(440, 226);
            this.textBox10.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox10.Name = "textBox10";
            this.textBox10.PasswordChar = '\0';
            this.textBox10.SelectedText = "";
            this.textBox10.SelectionLength = 0;
            this.textBox10.SelectionStart = 0;
            this.textBox10.Size = new System.Drawing.Size(124, 23);
            this.textBox10.TabIndex = 46;
            this.textBox10.UseSystemPasswordChar = false;
            // 
            // textBox11
            // 
            this.textBox11.Depth = 0;
            this.textBox11.Enabled = false;
            this.textBox11.Hint = "";
            this.textBox11.Location = new System.Drawing.Point(440, 284);
            this.textBox11.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox11.Name = "textBox11";
            this.textBox11.PasswordChar = '\0';
            this.textBox11.SelectedText = "";
            this.textBox11.SelectionLength = 0;
            this.textBox11.SelectionStart = 0;
            this.textBox11.Size = new System.Drawing.Size(124, 23);
            this.textBox11.TabIndex = 47;
            this.textBox11.UseSystemPasswordChar = false;
            // 
            // textBox9
            // 
            this.textBox9.Depth = 0;
            this.textBox9.Enabled = false;
            this.textBox9.Hint = "";
            this.textBox9.Location = new System.Drawing.Point(286, 226);
            this.textBox9.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox9.Name = "textBox9";
            this.textBox9.PasswordChar = '\0';
            this.textBox9.SelectedText = "";
            this.textBox9.SelectionLength = 0;
            this.textBox9.SelectionStart = 0;
            this.textBox9.Size = new System.Drawing.Size(124, 23);
            this.textBox9.TabIndex = 48;
            this.textBox9.UseSystemPasswordChar = false;
            // 
            // textBox12
            // 
            this.textBox12.Depth = 0;
            this.textBox12.Enabled = false;
            this.textBox12.Hint = "";
            this.textBox12.Location = new System.Drawing.Point(440, 345);
            this.textBox12.MouseState = MaterialSkin.MouseState.HOVER;
            this.textBox12.Name = "textBox12";
            this.textBox12.PasswordChar = '\0';
            this.textBox12.SelectedText = "";
            this.textBox12.SelectionLength = 0;
            this.textBox12.SelectionStart = 0;
            this.textBox12.Size = new System.Drawing.Size(124, 23);
            this.textBox12.TabIndex = 49;
            this.textBox12.UseSystemPasswordChar = false;
            // 
            // materialFlatButton1
            // 
            this.materialFlatButton1.AutoSize = true;
            this.materialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton1.Depth = 0;
            this.materialFlatButton1.Location = new System.Drawing.Point(476, 408);
            this.materialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialFlatButton1.Name = "materialFlatButton1";
            this.materialFlatButton1.Primary = false;
            this.materialFlatButton1.Size = new System.Drawing.Size(74, 36);
            this.materialFlatButton1.TabIndex = 50;
            this.materialFlatButton1.Text = "Agregar";
            this.materialFlatButton1.UseVisualStyleBackColor = true;
            this.materialFlatButton1.Click += new System.EventHandler(this.materialFlatButton1_Click);
            // 
            // materialFlatButton2
            // 
            this.materialFlatButton2.AutoSize = true;
            this.materialFlatButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton2.Depth = 0;
            this.materialFlatButton2.Location = new System.Drawing.Point(62, 408);
            this.materialFlatButton2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialFlatButton2.Name = "materialFlatButton2";
            this.materialFlatButton2.Primary = false;
            this.materialFlatButton2.Size = new System.Drawing.Size(82, 36);
            this.materialFlatButton2.TabIndex = 51;
            this.materialFlatButton2.Text = "Cancelar";
            this.materialFlatButton2.UseVisualStyleBackColor = true;
            this.materialFlatButton2.Click += new System.EventHandler(this.materialFlatButton2_Click);
            // 
            // Cajas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 459);
            this.Controls.Add(this.materialFlatButton2);
            this.Controls.Add(this.materialFlatButton1);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Cajas";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Agregar Cajas";
            this.Load += new System.EventHandler(this.Cajas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cYPNDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cajasBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private CYPNDataSet cYPNDataSet;
        private System.Windows.Forms.BindingSource cajasBindingSource;
        private CYPNDataSetTableAdapters.cajasTableAdapter cajasTableAdapter;
        private CYPNDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox comboBox1;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox3;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox4;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox2;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox6;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox7;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox8;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox13;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox10;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox11;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox9;
        private MaterialSkin.Controls.MaterialSingleLineTextField textBox12;
        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton1;
        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton2;
    }
}